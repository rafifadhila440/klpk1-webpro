<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Data_paket extends CI_Controller{
	public function index()
	{
		$data['paket'] = $this->ModelPaket->getPaket()->result_array();
		$this->load->view('admin/header');
		$this->load->view('admin/data_paket', $data);
	}
}


