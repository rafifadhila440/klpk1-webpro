<div class="container-fluid">
    <button class="btn btn-sm btn-primary mb-3"><i class="fas fa-plus fa-sm"></i>Tambah Paket</button>
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>NAMA PAKET</th>
            <th>DAYA PAKET</th>
            <th>SPESIFIKASI</th>
            <th>HARGA SEWA</th>
            <th colspan="3">AKSI</th>
        </tr>

        <?php
        $i = 1;
        foreach ($paket as $pkt) { ?>
            <tr>
                <td>
                    <?= $pkt['id_paket']; ?>
                </td>
                <td>
                    <?= $pkt['nama_paket']; ?>
                </td>
                <td>
                    <?= $pkt['daya_paket']; ?>
                </td>
                <td>
                    <?= $pkt['spesifikasi']; ?>
                </td>
                <td>
                    <?= $pkt['hrg_sewa']; ?>
                </td>
                <td>
                    <a href="<?= base_url('') . $pkt['id_paket']; ?>" class="badge badge-info"><i class="fas fa-edit"></i> Ubah</a>
                    <a href="<?= base_url('') . $pkt['id_paket']; ?>" onclick="return confirm('Kamu 
yakin akan menghapus <?= $judul . ' ' . $pkt['title']; ?> ?')" class="badge badge-danger"><i class="fas fa-trash"></i>
                        Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>
</div>